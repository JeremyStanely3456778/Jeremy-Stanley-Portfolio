$(function() {
	
	$( "#sliderVisual" ).slider({
		value: 0,
		min: 0,
		max: 10,
		step: 1,
		
			slide: function(event, ui ) {
			$( "#scale" ).val(ui.value + " scale");
	  }
	});
	
	$( "#scale" ).val(" move slider below");
	
});
