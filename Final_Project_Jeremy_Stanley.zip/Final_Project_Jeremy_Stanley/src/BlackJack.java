/*Jeremy Stanley
 Java Programming
 Summer 2018
 COP 2552
 This program simulates a blackjack game, playing against a dealer(Computer). There are a total of four java files
 which handle the functionality of this program. When compiling this program, make sure BlakJack.java is selected 
 first.
 */

import java.io.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Iterator;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.UnsupportedEncodingException;

public class BlackJack
{

public Hand player;
public Hand dealer;
public Deck deck;

public BlackJackGUI BlackJackGUI;

//variables to track wins and losses
int DealerWins = 0;
int PlayerWins = 0;
int DealerLose = 0;
int PlayerLose = 0;
int Tie = 0;
Date now = new Date();

public BlackJack()
{

	BlackJackGUI = new BlackJackGUI();
	BlackJackGUI.setPlayAction(new PlayAction());
	BlackJackGUI.setHitAction(new HitAction());
	BlackJackGUI.setStandAction(new StandAction());
	BlackJackGUI.setQuitAction(new QuitAction());
	BlackJackGUI.enablePlayButton();

}

class QuitAction implements ActionListener 
{ // action listener for quit button

public void actionPerformed (ActionEvent e)// prints game stats to  GameStats.txt.
{	
	
	try {

		FileWriter fw = new FileWriter("GameStats.txt", true);
			
		fw.append("\n----------------------------------Game Stats---------------------------\n");
		fw.append("Number of wins, loses, and ties on " + now + " for each game played before program ended.\n");
			for (int i = 0; i < 1; i++) {
				fw.append("\nTotal Number of Dealer Wins: " + DealerWins);
				fw.append("\nTotal Number of Player Wins: " + PlayerWins);
				fw.append("\nTotal Number of Dealer Losses: " + DealerLose);
				fw.append("\nTotal Number of Player Losses: " + PlayerLose);
			 }
			
		fw.close();	
		
			
		} catch (FileNotFoundException a) {
			// TODO Auto-generated catch block
			a.printStackTrace();
		} catch (UnsupportedEncodingException a) {
			// TODO Auto-generated catch block
			a.printStackTrace();
		} catch (IOException z) {
			// TODO Auto-generated catch block
			z.printStackTrace();
		}	
	
	
	


System.exit(0); //closes application
}
}


class PlayAction implements ActionListener 
{

public void actionPerformed (ActionEvent e) 
{
	deck = new Deck();
	deck.shuffle();
	player = new Hand();
	dealer = new Hand();
	player.add(deck.nextCard());
		dealer.add(deck.nextCard());
		player.add(deck.nextCard());
		dealer.add(deck.nextCard());
		BlackJackGUI.displayPlayer(player);
		BlackJackGUI.displayDealerCard(dealer.getTopCard());
if(!player.hasBlackJack() && !dealer.hasBlackJack() && !player.isBusted())
{
	BlackJackGUI.enableHitAndStandButtons();}

if(player.hasBlackJack() || dealer.hasBlackJack() || player.isBusted())
{

finishGame();

}
}
}

class HitAction implements ActionListener{

public void actionPerformed (ActionEvent e) {

if(!player.isBusted() && player.valueOf() !=21)// if player is busted and hand value does not equal 21 than takes next card
{

player.add(deck.nextCard());
BlackJackGUI.displayPlayer(player);

}

if(player.isBusted() || player.valueOf()==21)// if player busts and dealer has 21 than dealer wins
{
finishGame();}
}

}

class StandAction implements ActionListener{

public void actionPerformed (ActionEvent e) {

finishGame();

}

}

private void finishGame(){

if(player.hasBlackJack()) //player wins if they have blackjack 
{
	BlackJackGUI.displayDealer(dealer);
	BlackJackGUI.displayPlayer(player);
	BlackJackGUI.displayOutcome("Winner");
//increments game stat
PlayerWins++;
DealerLose++;
}

else if (dealer.hasBlackJack() && player.hasBlackJack()) // if both have blackjack than tie and push
{
	BlackJackGUI.displayDealer(dealer);
	BlackJackGUI.displayPlayer(player);
	BlackJackGUI.displayOutcome("Push (Tie)");
//increments game stat
Tie++;
}

else if(dealer.hasBlackJack()) // dealer wins if they have black jack
{
	BlackJackGUI.displayDealer(dealer);
	BlackJackGUI.displayPlayer(player);
	BlackJackGUI.displayOutcome("Lose");
//increments game stat
DealerWins++;
PlayerLose++;

}

else if (player.isBusted()) // id player is busted than dealer wins
{
	BlackJackGUI.displayDealer(dealer);
	BlackJackGUI.displayPlayer(player);
	BlackJackGUI.displayOutcome("Lose");
//increment game stats
PlayerLose++;
DealerWins++;
}

else 
{
while( dealer.valueOf() < 17 && !dealer.isBusted() ){ // if dealer hand value is less than 17 and is not busted take another card.

dealer.add(deck.nextCard());
}

if(dealer.isBusted()) // if dealer busts player wins

{
	BlackJackGUI.displayDealer(dealer);
	BlackJackGUI.displayPlayer(player);
	BlackJackGUI.displayOutcome("Winner");
//increment game stats
PlayerWins++;
DealerLose++;
}

else if (dealer.hasBlackJack())// if dealer has blackjack dealer wins
{
	BlackJackGUI.displayDealer(dealer);
	BlackJackGUI.displayPlayer(player);
	BlackJackGUI.displayOutcome("Lose");
//increment gamestats
PlayerLose++;
DealerWins++;

}

else if (dealer.valueOf() == player.valueOf())// if both hands are equal than it is a tie.

{
	BlackJackGUI.displayDealer(dealer);
	BlackJackGUI.displayPlayer(player);
	BlackJackGUI.displayOutcome("Push! It was a Tie");
//increment gamestats
Tie++;

}

else if (dealer.valueOf() > player.valueOf())//if dealer hand is greater than player, dealer wins
{
	BlackJackGUI.displayDealer(dealer);
	BlackJackGUI.displayPlayer(player);
	BlackJackGUI.displayOutcome("Lose");
//increment gamestats
DealerWins++;
PlayerLose++;
}

else if (player.valueOf() > dealer.valueOf())// if player hand is greater than dealer than player wins
{
	BlackJackGUI.displayDealer(dealer);
	BlackJackGUI.displayPlayer(player);
	BlackJackGUI.displayOutcome("Winner");
// increment game stats
PlayerWins++;
DealerLose++;
}
}

BlackJackGUI.enablePlayButton();

}
public static void main(String[] args){
new BlackJack();
}
}