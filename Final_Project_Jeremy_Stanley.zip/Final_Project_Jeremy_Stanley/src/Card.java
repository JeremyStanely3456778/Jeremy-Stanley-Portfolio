/*
 Jeremy Stanley
 Java Programming
 Summer 2018
 COP 2552
 This part handles the card values which are dealt to the players.*/

import java.awt.*;

import java.util.*;

public class Card 
{
// stores the cards numerical rank and Suit 
	private int CardSuit;

	private int CardNumberRank;

	private static final String[] cardsuits = {"Clubs", "Diamonds", "Hearts", "Spades"};

	private static final String[] cardNumberranks = {"Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King"};

public Card(int cardsuit, int cardrank)
{

	this.CardSuit = cardsuit;

	this.CardNumberRank = cardrank;

}

public int valueOf()
{

//returns the numerical value of the Card to be given to the player

if (this.CardNumberRank == 0)
{

	return 11; //cards determined value

}

if (this.CardNumberRank < 10)
{

	return CardNumberRank + 1; //cards determined value

}

if(this.CardNumberRank >= 10)
{

	return 10; //cards determined value

}

else
{

	return 0; //cards determined value

}

}

public String toString(){

//returns a String representing the Card in form "Ace/Three/King of Hearts"

	return cardNumberranks[this.CardNumberRank] + " of " + cardsuits[this.CardSuit];

}

public static void main(String[] args) // displays card value to console
{

	Card cardA = new Card(0,0);

System.out.println("This cards value is " + cardA.valueOf() + " and " + cardA.toString());

	Card cardB = new Card(3,4);

System.out.println("This cards value is " + cardB.valueOf() + " and " + cardB.toString());

	Card cardC = new Card(3,12);

System.out.println("This cards value is " + cardC.valueOf() + " and " + cardC.toString());

}

}