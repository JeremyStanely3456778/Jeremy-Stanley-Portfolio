//Jeremy Stanley
//Project 5
//COP2552.0M1
//Summer 2018
//This program creates a javafx GUI version of hangman. 



//start of imports
import java.util.*;
import javafx.animation.PathTransition;
import javafx.animation.Transition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import java.awt.event.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import java.util.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import java.awt.event.*;
import javafx.scene.shape.Circle;
import java.text.*;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.util.ArrayList;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
//end of imports
import java.io.UnsupportedEncodingException;




public class Hangman extends Application 
{
@Override


public void start(Stage primaryStage) throws Exception 
{

//initializes and sets up pane for game	
HangmanPane Gamepane = new HangmanPane();
Scene Gamescene = new Scene(Gamepane, 700, 700);
Gamescene.setOnKeyPressed(e-> {
Gamepane.sendKeyCode(e.getCode());
});

primaryStage.setScene(Gamescene);
primaryStage.setTitle("Hangman Game!");
primaryStage.show();
}


//intializes all variables for game and Path Transition animation (hanged man)

private class HangmanPane extends Pane 
{

//words to be guessed
private String[] words = {"Programming", "Computer", "Mac", "Ghost", "Java", "Linux", "Software", "System", "Google", "Python"};

//hieght and width of the scene/pane in relation to animation
private double Width = 700;
private double Height = 700;

//total number of guesses aloud
private final int NumberOfLivesGuesses = 7;

//initializes lines varialbes for animation
Line A;
Line B;
Line C;
Circle HeadofBody;
Line LeftArm;
Line RightArm;
Line Torso;
Line LeftLeg;
Line RightLeg;

String word;

//arrays hold letters that were guessed and incorrect
ArrayList<Character> CorrectGuess = new ArrayList<>();
ArrayList<Character> WrongGuess = new ArrayList<>();

Label HiddenWordLabel = new Label();
Label MissedLettersLabel = new Label();
Label MessageLabel = new Label();

//stores game stats to be saved to text file
int NumerofWins = 0;
int NumerofLosses = 0;
Date now = new Date();

boolean GameComensing = true;

PathTransition PathEvent;

HangmanPane() 
{
startGameRound();
}
private void startGameRound() 
{
getChildren().clear();
CorrectGuess.clear();
WrongGuess.clear();
if (PathEvent != null) 
{
	PathEvent.stop();
}
word = getRandomWord();

//adds stats to file
Button quitbtn = new Button("Save Game Stats and Quit!");

//event handler for quit button/saves stats to file before quitting 
quitbtn.setOnAction(
new EventHandler<ActionEvent>() {
@Override
public void handle(ActionEvent event) {
//actions performed when button is pressed
 


	try {

	FileWriter fw = new FileWriter("GameStats.txt", true);
		
	fw.append("\n----------------------------------Game Stats---------------------------\n");
	fw.append("Number of Wins and Losses on " + now + " for each game played before program ended.\n");
		for (int i = 0; i < 1; i++) {
			fw.append("\nTotal Number of Wins: " + NumerofWins);
			fw.append("\nTotal Number of Losses: " + NumerofLosses);
		 }
		
	fw.close();	
	
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (UnsupportedEncodingException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		
	
	    	
System.exit(0);
}
});


HiddenWordLabel.setText(getHiddenWord());
MissedLettersLabel.setText("Missed letters: \n ");
MessageLabel.setText("Next Round: Guess the letter to the Next Word!");
double x = Width * 0.4;
double y = Height * 0.8;
HiddenWordLabel.setLayoutX(x);
HiddenWordLabel.setLayoutY(y);
MissedLettersLabel.setLayoutX(x);
MissedLettersLabel.setLayoutY(y * 1.05);
MessageLabel.setLayoutX(x);
MessageLabel.setLayoutY(y * 1.15);
quitbtn.setLayoutX(1);
quitbtn.setLayoutY(1);
getChildren().addAll(HiddenWordLabel, MissedLettersLabel, MessageLabel, quitbtn);
create();
}
private void create() 
{
	
//sets width and height dimesions of figure varialbe and color
Arc Arcfigure = new Arc(Width * 0.2, Height * 0.9, Width * 0.15, Height * 0.15, 0, 180);
Arcfigure.setFill(Color.GREEN);
Arcfigure.setStroke(Color.ORANGE);
A = new Line(Arcfigure.getCenterX(), Arcfigure.getCenterY() - Arcfigure.getRadiusY(), Arcfigure.getCenterX(), Height * 0.05);
B = new Line(A.getEndX(), A.getEndY(), Width * 0.6, A.getEndY());
C = new Line(B.getEndX(), B.getEndY(), B.getEndX(), B.getEndY() + Height * 0.1);
getChildren().addAll(Arcfigure, A, B, C);
for (int x = 1; x <= CorrectGuess.size(); x++) 
{
CreateHangman(x);
}
}
private void CreateHangman(int PlayersGuess) 
{

switch (PlayersGuess) {

case 1: CreateHead(); break;

case 2: CreateBody(); break;

case 3: CreateLeftArm(); break;

case 4: CreateRightArm(); break;

case 5: CreateLeftLeg(); break;

case 6: CreateRightLeg(); break;

case 7: HangingAnimation(); break;
}

}

//creates swaying effect at end if all lives are lost
private void HangingAnimation() {
HeadofBody.translateXProperty().addListener((Observablevariable, OldVariable, NewVarialbe) -> {
	Torso.setTranslateX(NewVarialbe.doubleValue());
LeftArm.setTranslateX(NewVarialbe.doubleValue());
RightArm.setTranslateX(NewVarialbe.doubleValue());
LeftLeg.setTranslateX(NewVarialbe.doubleValue());
RightLeg.setTranslateX(NewVarialbe.doubleValue());
});
HeadofBody.translateYProperty().addListener((Observablevariable, OldVariable, NewVarialbe) -> {
	Torso.setTranslateY(NewVarialbe.doubleValue());
LeftArm.setTranslateY(NewVarialbe.doubleValue());
RightArm.setTranslateY(NewVarialbe.doubleValue());
LeftLeg.setTranslateY(NewVarialbe.doubleValue());

RightLeg.setTranslateY(NewVarialbe.doubleValue());

});

//dimessions for head
Arc arc = new Arc(C.getEndX(), C.getEndY() + HeadofBody.getRadius() - 10, 20, 10, 220, 85);

arc.setFill(Color.TRANSPARENT);

arc.setStroke(Color.BLACK);

PathEvent = new PathTransition(Duration.seconds(3), arc, HeadofBody);

PathEvent.setCycleCount(Transition.INDEFINITE);

PathEvent.setAutoReverse(true);

PathEvent.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);

PathEvent.play();

}

//initializes body part and adds to scene/pane
private void CreateHead() 
{

double radius = Width * 0.1;

HeadofBody = new Circle(C.getEndX(), C.getEndY() + radius, radius, Color.PINK);

HeadofBody.setStroke(Color.PINK);

getChildren().add(HeadofBody);

}


//initializes body part and adds to scene/pane
private void CreateBody() 
{

double startY = HeadofBody.getCenterY() + HeadofBody.getRadius();

double x = HeadofBody.getCenterX();

Torso = new Line(x, startY, x, startY + Height * 0.25);

this.getChildren().add(Torso);

}

//initializes body part and adds to scene/pane
private void CreateLeftArm() 
{

	LeftArm = DisplayArm(-1, 225);

this.getChildren().add(LeftArm);

}

//initializes body part and adds to scene/pane
private void CreateRightArm() 
{

	RightArm = DisplayArm(1, 315);

this.getChildren().add(RightArm);

}

//initializes body part and adds to scene/pane
private void CreateLeftLeg() 
{

	LeftLeg = DisplayLeg(-1);

this.getChildren().add(LeftLeg);

}

//initializes body part and adds to scene/pane
private void CreateRightLeg() 
{

	RightLeg = DisplayLeg(1);

this.getChildren().add(RightLeg);

}

//initializes body part and adds to scene/pane
private Line DisplayLeg(int LG) 
{

double X = Torso.getEndX();

double Y = Torso.getEndY();

return new Line(X, Y, X + HeadofBody.getRadius() * LG, Y + Width * 0.2);

}

//initializes body part and adds to scene/pane
private Line DisplayArm(int LG, double AngleVariable) 
{

double RadiousVariable = HeadofBody.getRadius();

double X = HeadofBody.getCenterX() + RadiousVariable * Math.cos(Math.toRadians(AngleVariable));

double Y = HeadofBody.getCenterY() - RadiousVariable * Math.sin(Math.toRadians(AngleVariable));

return new Line(X, Y, X + RadiousVariable * LG, Y + RadiousVariable * 1.5);

}

//left off here

private boolean EntersGuess(char charvariable) 
{

if (!GameComensing) return false;

// Checks if the guess has been used before

if (isRepeatedGuess(charvariable)) {

	MessageLabel.setText(charvariable + " has already been used! Try another letter!");

return false; // return false on repeated guesses

}

// Add letter to guess history

CorrectGuess.add(charvariable);

String NewWordNextRound = getHiddenWord(); // retrieve new word

// Check if guess is correct

// if newWord == hidden word then guess was incorrect

if (NewWordNextRound.equalsIgnoreCase(HiddenWordLabel.getText())) 
{

	WrongGuess.add(charvariable); // keep track of incorrect guesses

if ((WrongGuess.size() == NumberOfLivesGuesses)) 
{ 

	MessageLabel.setText("Game Over! Press enter and try again!");
	
	NumerofLosses++; //increases losses counter---------------------------------------------------------------> 

	GameComensing = false; // Player can't make a guess until he presses enter

} else 
{

	MessageLabel.setText(charvariable + " is an incorrect guess! \nThere are " + (NumberOfLivesGuesses - WrongGuess.size()) + " lives left.");

}

MissedLettersLabel.setText(MissedLettersLabel.getText() + Character.toLowerCase(charvariable));

CreateHangman(WrongGuess.size()); // draw hangman

return false; // return false their is an  incorrect guess

} else 
{

// Code reaches here if guess is correct

	HiddenWordLabel.setText(NewWordNextRound);

String W = "Correct Guess!";

// Checks to see if the user won the game

if (NewWordNextRound.equalsIgnoreCase(word)) 
{

W += " Congradulations. You won the game! \n Press Enter to play a new round!";

NumerofWins++; //increeases wins counter------------------------------------------------------------------------>

System.out.println(NumerofWins);//------------------------------------------------------------------------------>
System.out.println(NumerofLosses);

GameComensing = false;

}

MessageLabel.setText(W);

}

return true;

}

//checks if entered was pressed to play another round
public void sendKeyCode(KeyCode keyData) 
{

if (keyData == KeyCode.ENTER && !GameComensing) 
{

	GameComensing = true;

	startGameRound();

} else if (keyData.isLetterKey()) 
{

	EntersGuess(keyData.getName().charAt(0));

}

}

//checks to see if hidden word is repeated or nots
private boolean isRepeatedGuess(char charvariable) 
{

	charvariable = Character.toUpperCase(charvariable);

for (char letter : CorrectGuess) 
{

if (letter == charvariable) 
{

return true;

}

}

return false;

}

// retrives a new hidden word for the next round
private String getHiddenWord() 
{

String W = "";

for (int a = 0; a < word.length(); a++) 
{

boolean WordMatched = false;

for (char chardata : CorrectGuess) 
{

if (Character.toLowerCase(chardata) == Character.toLowerCase(word.charAt(a))) 
{

W += word.charAt(a);

WordMatched = true;

break;

}

}

if (!WordMatched) 
{

W += "*";

}

}

return W;

}

//genrates random word from array
private String getRandomWord() 
{

return words[(int) (Math.random() * words.length)];

}

}

public static void main(String[] args) 
{

Application.launch(args);

}


}

