/*Jeremy Stanley
 Java Programming
 Summer 2018
 COP 2552
 This part of the program simulates shuffling the deck for the blackjack game. */

import java.awt.*;
import java.util.*;

public class Deck
{

private Card[] BlackJackDeck = new Card[52]; // array for the blackjack deck

private int DeckSize = 0;

public Deck() 
{
int DeckSize2 = 0;

for(int index =0; index < 4; index++)
{
for(int index2 = 0; index2 < 13; index2++)
{
Card size = new Card(index, index2);
BlackJackDeck[DeckSize2] = size;
DeckSize2++;
}
}
}

public void shuffle() // this part shuffles the deck
{
	DeckSize = 0;
	
int shufflecounter=0;

while (shufflecounter < 1000) 
{
Random randomcardplacement = new Random(); // this part places each card into a random spot in the deck
int x= randomcardplacement.nextInt(52);
int y= randomcardplacement.nextInt(52);
Card StoredCard = BlackJackDeck[x];
BlackJackDeck[x] = BlackJackDeck[y];
BlackJackDeck[y] = StoredCard;
shufflecounter++;
}
}

public boolean hasNextCard()
{
return DeckSize < 52;

}
public Card nextCard()
{
if(DeckSize < 52)
{
	DeckSize++;
return BlackJackDeck[DeckSize - 1];
}
else
{
return null;
}
}

public static void main(String[] args)
{
Deck deck = new Deck();

System.out.println(deck.toString());

while(deck.hasNextCard()){

System.out.println(deck.nextCard());

}

deck.shuffle();

System.out.println(deck.toString());

while(deck.hasNextCard()){

System.out.println(deck.nextCard());

}
}
}
