//Jeremy Stanley
//COP 2552.0M1
//Summer 2018
//This program lets the user choose between hangman, Yahtzee, or Blackjack, then executes that game.
//Make sure to have LaunchJavaFXGame.java selected before compiling and running program. 

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.control.Label;

public class LaunchJavaFXGame extends Application 
{

//initializes buttons for LaunchJavaFXGame interface
public Button Button1, Button2, Button3;

@Override

public void start(Stage primaryStage) 
{

//initializes gridpanes and button text	for LaunchJavaFXGame interface
GridPane grid = new GridPane();

Button1 = new Button("Play Yahtzee");

//directions for the game launcher interface. 
Label directionslabel = new Label("Choose a Game to Play!");
grid.add(directionslabel, 1, 9);

Button1.setId("0");
Button1.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
grid.add(Button1, 0, 1);

Button2 = new Button("Play BlackJack");
Button2.setId("1");
Button2.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
grid.add(Button2, 1,1);

Button3 = new Button("Play Hangman");
Button3.setId("2");
Button3.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
grid.add(Button3, 2, 1);

Scene scene = new Scene(grid, 400, 100);
primaryStage.setScene(scene);
primaryStage.setResizable(true);
primaryStage.setTitle("Game Launcher");
primaryStage.show();

//intializes action event handlers for interface button

Button1.setOnAction(new EventHandler<ActionEvent>() 
{
@Override
public void handle(ActionEvent event) 
{
//create an object of the class you wish to invoke its start() method:
Yahtzee yahtzeeObj = new Yahtzee();
// Then call its start() method in the following way:
yahtzeeObj.start(primaryStage);
}
});

Button2.setOnAction(new EventHandler<ActionEvent>() 
{
@Override
public void handle(ActionEvent event) 
{
//create an object of the class you wish to invoke main method for blackjack object
BlackJack blackJackObj = new BlackJack();
// Then call its start() method in the following way:
blackJackObj.main(null);
}
});

Button3.setOnAction(new EventHandler<ActionEvent>() 
{
@Override
public void handle(ActionEvent event) 
{
//create an object of the class you wish to invoke its start() method:
Hangman hangmanObj = new Hangman();
// Then call its start() method in the following way:
try 
{
hangmanObj.start(primaryStage);// if button action does not go as planned performs stack trace
}
catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
}
});
}

public static void main(String[] args) {

launch(args);

}
}

