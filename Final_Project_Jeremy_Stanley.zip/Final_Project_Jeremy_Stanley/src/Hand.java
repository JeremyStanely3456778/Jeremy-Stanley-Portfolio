/*
 *eremy Stanley
 Java Programming
 Summer 2018
 COP 2552
 This part deals with dealing out the hand to each player*/

import java.awt.*;
import java.util.*;

public class Hand
{
public int count = 0;
private Card[] DealerPlayerHand;

public Hand() 
{
	DealerPlayerHand = new Card[20]; // this part limits the hand to 20
}

public void add(Card card)
{
	DealerPlayerHand[count++] = card; // keeps count of cords in hands
}

public Card getTopCard()
{
return DealerPlayerHand[0];
}

public int valueOf()
{
int total = 0;
int cardnumrank = 0;
int secondcount = count;
int dealtaces = 0;
for(int inedx = 0; inedx < secondcount; inedx++)
{
	cardnumrank = DealerPlayerHand[inedx].valueOf();
	total += cardnumrank;
if( cardnumrank == 11)
{
	dealtaces++;
}
}

while (dealtaces > 0 && total > 21)
{
	total -= 10;
	dealtaces--;
}
return total;
}

public boolean hasBlackJack() // determines if there is blackjack
{
int total = DealerPlayerHand[0].valueOf() + DealerPlayerHand[1].valueOf();
return total == 21;
}

public boolean isBusted() // determines if hand is busted
{
return valueOf() > 21;
}

public String toString()
{
String string ="";
int count3 = count;

for(int i=0; i < count3; i++)
{
string += DealerPlayerHand[i].toString();
string += "\n";
}

if(isBusted())// busted if total of hand is over 21
{
string += "\n\n";
string += "Bust! Went over 21";
}

if(hasBlackJack())// player whom has blackjack is winner
{
string += "\n\n";
string += "Winner!";
}
return string;
}

public static void main(String[] args) 
{
Deck deck = new Deck();
deck.shuffle();
Hand handA = new Hand();
handA.add(deck.nextCard());
handA.add(deck.nextCard());
handA.add(deck.nextCard());
System.out.println(handA.toString());
System.out.println(handA.valueOf());
}
}