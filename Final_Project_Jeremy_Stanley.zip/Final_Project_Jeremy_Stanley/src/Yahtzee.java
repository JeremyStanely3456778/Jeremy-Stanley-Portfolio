//Jeremy Stanley
//COP 2552.0M1
//Summer 2018
// This program runs a simple Yahtzee game in Java with JavaFx GUI.

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.layout.GridPane;
import java.io.*;
import java.util.*;
import java.util.ArrayList;
import java.util.Collections;
import javafx.geometry.Pos;
import javafx.scene.control.TextField;
import java.util.ArrayList;
import java.util.Collections;
import java.io.*;
import java.util.*;

 //This class is a very basic template for a JavaFx Application
 //All of the above imports are required to ensure you have
 //The majority of the functionality most JavaFx Applications
 //require
public class Yahtzee extends Application {
   public static void main(String[] args) {
      launch(args);
   
   
   }


   public void start(Stage primaryStage) {
	 
	   
	   
	
	   
	 GridPane root = new GridPane();
	 
	 

	   //set default alignment to center
	   root.setAlignment(Pos.CENTER);
	   
	   
	 //create a window with a size of 300 x 250
	   primaryStage.setScene(new Scene(root, 300, 250));
	  //make it visible
	  primaryStage.show(); 
	  
	  
	  Button btn = new Button("Press Button to Quit!");
	  root.add(btn, 7, 0);
	  
	  btn.setOnAction(
		         new EventHandler<ActionEvent>() {
		            @Override
		            public void handle(ActionEvent event) {
		            //put your action here
		                System.exit(0);
		            	

		              }
		         });
	  
	  
	  
	  
	  
	  
	  
	 
	   int[] aDice = new int[] {0, 0, 0, 0, 0 }; //intizlizes an array
	   
	   //generates random dice rolls
	   Random rand = new Random();
	      for (int A = 0; A < 5; A++) { 
	    	 
	        aDice[A] = 1 + rand.nextInt(6);// sets the dice value
	        
	        //print out dice rolls for texting
	        System.out.print("\n\nDice Roll: " + aDice[A]);
	      }
	      
	
   
	 //sets title for window
	   primaryStage.setTitle("Yahtzee Dice Roll");
	   
	   //displays results of the five dice rolls
	   final Label label0 = new Label("\n\nResult of Dice Rolls(Red Border Indicates dice held):");
	   final Label label1 = new Label("\nDie 1: " + aDice[0]);
	   final Label label2 = new Label("\nDie 2: " + aDice[1]);
	   final Label label3 = new Label("\nDie 3: " + aDice[2]);      
	   final Label label4 = new Label("\nDie 4: " + aDice[3]);
	   final Label label5 = new Label("\nDie 5: " + aDice[4]);

	    
	  //place label 0               
	   root.add(label0,0,0);		
	   		                          
	   //place label2 				
	   root.add(label1,0,1);         
	 //place label2  
	   root.add(label2,0,2);
	 //place label2  
	   root.add(label3,0,3);
	 //place label2  
	   root.add(label4,0,4);
	 //place label2  
	   root.add(label5,0,5);
	  
	 
	 
	  //asks player to input how many dice to hold
	  TextField input;
	  root.add(new Label ("How many dice to hold: "), 0, 6);
	  input = new TextField();
	  
	  root.add(input, 0, 7);
	  
	  Button Enter = new Button ("Press for second dice roll!");
	  root.add(Enter, 0, 8);
	  
	  
	  Enter.setOnAction(new EventHandler<ActionEvent>() {
	        @Override public void handle(ActionEvent e) {
	          int  RollA = Integer.parseInt(input.getText());
	          
	          //input validation
	          if(RollA < 1 || RollA > 6) {
	        	final  Label InvalidData = new Label("Error! Input must be an integer and 1-6");
	        	root.add(InvalidData, 1, 7);
	        	  
	          }
	          
	        
	          if (RollA > 0) {
	          
	              Random rand = new Random();
	              for (int B = 0; B < RollA; B++) {
	              int	RoleB = 1 + rand.nextInt(6); // generates more numbers between 1-6 to simulate dice roll
	              	aDice[B] = RoleB;
	              	
	              //print out dice rolls for texting
	    	        System.out.print("\n\nDice Roll: " + aDice[B]);	
	              	
	              }
	              
	           // adds second set of dice roles
	       	   final Label label6 = new Label("\n\nResult of Second set of Dice Rolls(Red Border Indicates dice held):");
	       	   final Label label7 = new Label("\nDie 1: " + aDice[0]);
	       	if (RollA < 1) {
	       		   label7.setStyle("-fx-border-color: red");
	       	   }
	       	   final Label label8 = new Label("\nDie 2: " + aDice[1]);
	       	   if (RollA < 2) {
	       		   label8.setStyle("-fx-border-color: red");
	       	   }
	       	   
	       	   final Label label9 = new Label("\nDie 3: " + aDice[2]);   
	       	if (RollA < 3) {
	       		   label9.setStyle("-fx-border-color: red");
	       	   }
	       	   final Label label10 = new Label("\nDie 4: " + aDice[3]);
	       	if (RollA < 4) {
	       		   label10.setStyle("-fx-border-color: red");
	       	   }
	       	   final Label label11 = new Label("\nDie 5: " + aDice[4]);
	       	if (RollA < 5) {
	       		   label11.setStyle("-fx-border-color: red");
	       	   }
	       	      
	              
	            //place label 0
	       	   root.add(label6,0,9);
	       	   //place label2 
	       	   root.add(label7,0,10);
	       	 //place label2  
	       	   root.add(label8,0,11);
	       	 //place label2  
	       	   root.add(label9,0,12);
	       	 //place label2  
	       	   root.add(label10,0,13);
	       	 //place label2  
	       	   root.add(label11,0,14);
	       	   
	        
	          }
	        
	        }
	    });
	  
	  
	  TextField Lastinput;
	  root.add(new Label ("How many dice to hold: "), 0, 19);
	  Lastinput = new TextField();
	  
	  root.add(Lastinput, 0, 20);
	  
	  Button Enter2 = new Button ("Press for second dice roll!");
	  root.add(Enter2, 0, 21);
	  
	  
	  Enter2.setOnAction(new EventHandler<ActionEvent>() {
	        @Override public void handle(ActionEvent e) {
	          int  RollB = Integer.parseInt(Lastinput.getText());
	          
	        //input validation
	          if(RollB < 1 || RollB > 6) {
	        	final  Label InvalidData2 = new Label("Error! Input must be an integer and 1-6");
	        	root.add(InvalidData2, 1, 20);
	        	  
	          }
	        
	          if (RollB > 0) {
	          
	              Random rand = new Random();
	              for (int B = 0; B < RollB; B++) {
	              int	RoleB = 1 + rand.nextInt(6); // generates more numbers between 1-6 to simulate dice roll
	              	aDice[B] = RoleB;
	              	
	              //print out dice rolls for texting
	    	        System.out.print("\n\nDice Roll: " + aDice[B]);
	              }
	              
	           // adds second set of dice roles
	       	   final Label label12 = new Label("\n\nResult of Third set of Dice Rolls(Red Border Indicates dice held):");
	       	   final Label label13 = new Label("\nDie 1: " + aDice[0]);
	       	if (RollB < 1) {
	       		   label13.setStyle("-fx-border-color: red");
	       	   }
	       	   final Label label14 = new Label("\nDie 2: " + aDice[1]);
	       	if (RollB < 2) {
	       		   label14.setStyle("-fx-border-color: red");
	       	   }
	       	   final Label label15 = new Label("\nDie 3: " + aDice[2]);
	       	if (RollB < 3) {
	       		   label15.setStyle("-fx-border-color: red");
	       	   }
	       	   final Label label16 = new Label("\nDie 4: " + aDice[3]);
	       	if (RollB < 4) {
	       		   label16.setStyle("-fx-border-color: red");
	       	   }
	       	   final Label label17 = new Label("\nDie 5: " + aDice[4]);
	       	if (RollB < 5) {
	       		   label17.setStyle("-fx-border-color: red");
	       	   }
	       	      
	              
	            //place label 0
	       	   root.add(label12,0,25);
	       	   //place label2 
	       	   root.add(label13,0,26);
	       	 //place label2  
	       	   root.add(label14,0,27);
	       	 //place label2  
	       	   root.add(label15,0,28);
	       	 //place label2  
	       	   root.add(label16,0,29);
	       	 //place label2  
	       	   root.add(label17,0,30);
	        
	        
	          }
	        
	        }
	    });
	  
	  TextField PlayersInput;
	  root.add(new Label ("Choose which one: "), 0, 39);
	  PlayersInput = new TextField();
	  
	  root.add(PlayersInput, 0, 40);
	  
	  
	  Button scorebtn = new Button ("Score Dice Rolls"); // score button
	  root.add(scorebtn, 0, 42);
	  
	  scorebtn.setOnAction(new EventHandler<ActionEvent>() {
	        @Override public void handle(ActionEvent e) {
	        	
	        	//parses player input
	        	int  Parsedinput = Integer.parseInt(PlayersInput.getText());
	        	
	        	int score = 0;
	        	
	        	
	        	int index = 0, i = 0, TotalWon = 0, TotalWon2 = 0;
			      
			      int one = 0, two = 0, three = 0, four = 0, five = 0, six = 0;
			      
			      List Scoredata = new ArrayList();
			      
			      Arrays.sort(aDice); //sorts array in ascending numerical order
	        	
	        	//Numbers
			      for ( int c = 0; c < 5; c++) {
			        if (aDice[c] == 1) {one++;}
			        if (aDice[c] == 2) {two++; }
			        if (aDice[c] == 3) {three++;}
			        if (aDice[c] == 4) {four++;}
			        if (aDice[c] == 5) {five++;}
			        if (aDice[c] == 6) {six++;}
			      }
			   
			      //calculates straights from the dice rolls
			      if ((aDice[0] == aDice[1] - 1) && (aDice[1] == aDice[2] - 1)
			          && (aDice[2] == aDice[3] - 1) && (aDice[3] == aDice[4] - 1)
			          && (Parsedinput == 3)) 
			      {
			    	  TotalWon2 = 1;
			      } 
			      else if ((one > 0) && (two > 0) && (three > 0) && (four > 0)) 
			      {
			    	  TotalWon2 = 2;
			      } 
			      else if ((three > 0) && (four > 0) && (five > 0) && (six > 0)) 
			      {
			    	  TotalWon2 = 2;
			      } 
			      else if ((two > 0) && (three > 0) && (four > 0) && (five > 0)) 
			      {
			    	  TotalWon2 = 2;
			      }
			   
			      //calculates pairs from rolled dice
			      for (index = 0; index < 5; index++) 
			      {
			        if (index != 0) {
			          if ((aDice[0] == aDice[index])) 
			          {
			        	  TotalWon++;
			          }
			        }
			        if ((index != 0) && (index != 1)) 
			        {
			          if ((aDice[1] == aDice[index])) 
			          {
			        	  TotalWon++;
			          }
			        }
			        if ((index != 0) && (index != 1) && (index != 2)) 
			        {
			          if ((aDice[2] == aDice[index])) 
			          {
			        	  TotalWon++;
			          }
			        }
			        if ((index != 0) && (index != 1) && (index != 2) && (index != 3)) 
			        {
			          if ((aDice[3] == aDice[index])) {
			        	  TotalWon++;
			          }
			        }
			      }
			      
			      
			      
			      
			   String outcome;
			      //Displays outcome of game and What user has scored
			      if ((TotalWon2 == 1) && (Parsedinput == 3)) 
			      {
			    	  final Label scorelabel1 = new Label("Its a straight.");
			    	  root.add(scorelabel1, 0, 44);
			    	  final Label scoretotal = new Label("Score Total is : " + score);
			    	  root.add(scoretotal, 1, 44);
			    	  
			        System.out.println("\nIt's a straight.");
			        score = 40;
			        
			      }
			      else if ((TotalWon2 == 2) && (Parsedinput == 4))
			      {
			    	  final Label scorelabel1 = new Label("Its a straight");
			    	  root.add(scorelabel1, 0, 44);
			    	  final Label scoretotal = new Label("Score Total is : " + score);
			    	  root.add(scoretotal, 1, 44);
			    	  
			        System.out.println("\nIt's a small straight.");
			        score = 30;
			      }
			      else if ((TotalWon == 10) && (Parsedinput == 1)) 
			      {
			    	  final Label scorelabel1 = new Label("You got Yahtzee Hurray");
			    	  root.add(scorelabel1, 0, 44);
			    	  final Label scoretotal = new Label("Score Total is : " + score);
			    	  root.add(scoretotal, 1, 44);
			    	  
			        System.out.println("\nYou got Yatzee Hurray!");
			        score = 50;
			      } 
			      else if ((Parsedinput == 6) && (TotalWon >= 3)) 
			      {
			    	  final Label scorelabel1 = new Label("\nYou rolled three of a kind.");
			    	  root.add(scorelabel1, 0, 44);
			    	  final Label scoretotal = new Label("Score Total is : " + score);
			    	  root.add(scoretotal, 1, 44);
			    	  
			        System.out.println("\nThree of a kind.");
			        score = aDice[0] + aDice[1] + aDice[2] + aDice[3] + aDice[4];
			      } 
			      else if ((Parsedinput == 7) && (TotalWon > 0)) 
			      {
			    	  final Label scorelabel1 = new Label("\nYou rolled a pair.");
			    	  root.add(scorelabel1, 0, 44);
			    	  final Label scoretotal = new Label("Score Total is : " + score);
			    	  root.add(scoretotal, 1, 44);
			    	  
			    	  
			        System.out.println("\nYou rolled a pair.");
			        score = 5;
			      } 
			      else if ((TotalWon == 2) && (Parsedinput == 8)) 
			      {
			    	  final Label scorelabel1 = new Label("\nYou rolled two pairs.");
			    	  root.add(scorelabel1, 0, 44);
			    	  final Label scoretotal = new Label("Score Total is : " + score);
			    	  root.add(scoretotal, 1, 44);
			    	  
			    	  
			        System.out.println("\nYou rolled two pairs.");
			        score = 10;
			      } 
			      else if ((TotalWon == 4) && (Parsedinput == 2)) 
			      {
			    	  final Label scorelabel1 = new Label("You rolled a full house");
			    	  root.add(scorelabel1, 0, 44);
			    	  final Label scoretotal = new Label("Score Total is : " + score);
			    	  root.add(scoretotal, 1, 44);
			    	  
			    	  
			    	  
			        System.out.println("\nYou rolled a full house.");
			        score = 25;
			      } 
			      else if ((TotalWon >= 6) && (Parsedinput == 5)) 
			      {
			    	  final Label scorelabel1 = new Label("\nYou rolled four of a kind.");
			    	  root.add(scorelabel1, 0, 44);
			    	  final Label scoretotal = new Label("Score Total is : " + score);
			    	  root.add(scoretotal, 1, 44);
			    	  
			        System.out.println("\nYou rolled four of a kind.");
			        score = aDice[0] + aDice[1] + aDice[2] + aDice[3] + aDice[4];
			      } 
			      else if (Parsedinput == 9) 
			      {
			    	  final Label scorelabel1 = new Label("\nYour get " + score + " points..");
			    	  root.add(scorelabel1, 0, 44);
			    	  final Label scoretotal = new Label("Score Total is : " + score);
			    	  root.add(scoretotal, 1, 44);
			    	  
			    	  
			        System.out.println("\nYou have " + one + " ones.");
			        score = one;
			      } 
			      else if (Parsedinput == 10) 
			      {
			    	  final Label scorelabel1 = new Label("\nYour get " + two + " points..");
			    	  root.add(scorelabel1, 0, 44);
			    	  final Label scoretotal = new Label("Score Total is : " + score);
			    	  root.add(scoretotal, 1, 44);
			    	  
			    	  
			        System.out.println("\nYou have " + two + " twos.");
			        score = two * 2;
			      } 
			      else if (Parsedinput == 11) 
			      {
			    	  final Label scorelabel1 = new Label("\nYou have " + three + " points..");
			    	  root.add(scorelabel1, 0, 44);
			    	  final Label scoretotal = new Label("Score Total is : " + score);
			    	  root.add(scoretotal, 1, 44);
			    	  
			    	  
			        System.out.println("\nYou have " + three + " threes.");
			        score = three * 3;
			      } 
			      else if (Parsedinput == 12) 
			      {
			    	  final Label scorelabel1 = new Label("\nYou have " + four + " points..");
			    	  root.add(scorelabel1, 0, 44);
			    	  final Label scoretotal = new Label("Score Total is : " + score);
			    	  root.add(scoretotal, 1, 44);
			    	  
			    	  
			        System.out.println("\nYou have " + four + " fours.");
			        score = four * 4;
			      } 
			      else if (Parsedinput == 13) 
			      {
			    	  
			    	  final Label scorelabel1 = new Label("You have" + five + " points..");
			    	  root.add(scorelabel1, 0, 44);
			    	  final Label scoretotal = new Label("Score Total is : " + score);
			    	  root.add(scoretotal, 1, 44);
			    	  
			    	  
			    	  
			        System.out.println("\nYou have " + five + " fives.");
			        score = five * 5;
			      } 
			      else if (Parsedinput == 14)
			      {
			    	  final Label scorelabel1 = new Label("Your have " + six + " points..");
			    	  root.add(scorelabel1, 0, 44);
			    	  final Label scoretotal = new Label("Score Total is : " + score);
			    	  root.add(scoretotal, 1, 44);
			    	 
			    	  
			        System.out.println("\nYou have " + six + " sixes.");
			        score = six * 6;
			      } 
			      else if (Parsedinput == 15) 
			      {
			    	  
			    	  final Label scorelabel1 = new Label("\nYour get " + score + " points..");
			    	  root.add(scorelabel1, 0, 44);
			    	  final Label scoretotal = new Label("Score Total is : " + score);
			    	  root.add(scoretotal, 1, 44);
			    	  
			    	  
			    	  
			        score = aDice[0] + aDice[1] + aDice[2] + aDice[3] + aDice[4];
			        System.out.println("\nYour get " + score + " points.");
			      } 
			      else 
			      {
			    	  final Label scorelabel1 = new Label("\nSorry, nothing.");
			    	  root.add(scorelabel1, 0, 44);
			    	  
			    	  final Label scoretotal = new Label("Score Total is : " + score);
			    	  root.add(scoretotal, 1, 44);
			    	  
			    	  
			    	  
			        System.out.println("\nSorry, nothing.");
			        score = 0;
			        outcome = "Sorry, nothing!";
			        
			      }
			      
			      }   
	        
	        
	       //saves score data from game round to file
	        
	        
	        
	        	
	        	
	        	
	        	
	        	
	        });   
	  
	  
   
	  
	  
	  
	  //Directions on how to play game and Use interface
	   		final Label Directions = new Label ("The application plays five rounds of Yahtzee.\n "
	 + "The first set of rolls is done automatically.\n Input how much you want ot hold, then press button and your result will be scored.");
	            root.add(Directions, 5,38);
	  
	 

	  //All variables names have had a "2" or "A" added to the end.  	  
	  //once the new game button is pressed a new game round is started.
	  
	  
	  Button NewGamebtn = new Button("Start Round 2");
	  root.add(NewGamebtn, 9, 0);
//-------------------------------Code of New Game Started from button press--------------------------//  
	   
	  NewGamebtn.setOnAction(e -> {
		  GridPane root2 = new GridPane();

		   //set default alignment to center
		   root2.setAlignment(Pos.CENTER);
		   
		   
		 //create a window with a size of 300 x 250
		   primaryStage.setScene(new Scene(root2, 300, 250));
		  //make it visible
		  primaryStage.show(); 
		  
		  
		  
		  Button btn2 = new Button("Press Button to Quit!");
		  root2.add(btn2, 7, 0);
		  
		  btn2.setOnAction(
			         new EventHandler<ActionEvent>() {
			            @Override
			            public void handle(ActionEvent event) {
			            //put your action here
			                System.exit(0);
			            	

			              }
			         });
		
	  
	  
	  
		   int[] aDice2 = new int[] {0, 0, 0, 0, 0 }; //intizlizes an array
		   
		   //generates random dice rolls
		   Random rand2 = new Random();
		      for (int A2 = 0; A2 < 5; A2++) { 
		    	 
		        aDice2[A2] = 1 + rand2.nextInt(6);// sets the dice value
		        
		        //print out dice rolls for texting
		        System.out.print("\n\nDice Roll: " + aDice2[A2]);
		      }
		      
		
	   
		 //sets title for window
		   primaryStage.setTitle("Yahtzee Dice Roll");
		   
		   //displays results of the five dice rolls
		   final Label label0A = new Label("\n\nResult of Dice Rolls(Red Border Indicates dice held):");
		   final Label label1A = new Label("\nDie 1: " + aDice2[0]);
		   final Label label2A = new Label("\nDie 2: " + aDice2[1]);
		   final Label label3A = new Label("\nDie 3: " + aDice2[2]);      
		   final Label label4A = new Label("\nDie 4: " + aDice2[3]);
		   final Label label5A = new Label("\nDie 5: " + aDice2[4]);

		    
		  //place label 0
		   root2.add(label0A,0,0);
		   //place label2 
		   root2.add(label1A,0,1);
		 //place label2  
		   root2.add(label2A,0,2);
		 //place label2  
		   root2.add(label3A,0,3);
		 //place label2  
		   root2.add(label4A,0,4);
		 //place label2  
		   root2.add(label5A,0,5);
		  
		 
		 
		  //asks player to input how many dice to hold
		  TextField inputA;
		  root2.add(new Label ("How many dice to hold: "), 0, 6);
		  inputA = new TextField();
		  
		  root2.add(inputA, 0, 7);
		  
		  Button EnterA = new Button ("Press for second dice roll!");
		  root2.add(EnterA, 0, 8);
		  
		  
		  EnterA.setOnAction(new EventHandler<ActionEvent>() {
		        @Override public void handle(ActionEvent e) {
		          int  RollA = Integer.parseInt(inputA.getText());
		          
		        //input validation
		          if(RollA < 1 || RollA > 6) {
		        	final  Label InvalidData2 = new Label("Error! Input must be an integer and 1-6");
		        	root2.add(InvalidData2, 1, 7);
		        	  
		          }
		          
		          
		        
		          if (RollA > 0) {
		          
		              Random rand = new Random();
		              for (int B = 0; B < RollA; B++) {
		              int	RoleBA = 1 + rand.nextInt(6); // generates more numbers between 1-6 to simulate dice roll
		              	aDice2[B] = RoleBA;
		              	
		              //print out dice rolls for texting
		    	        System.out.print("\n\nDice Roll: " + aDice2[B]);	
		              	
		              }
		              
		           // adds second set of dice roles
		       	   final Label label6A = new Label("\n\nResult of Second set of Dice Rolls(Red Border Indicates dice held):");
		       	   final Label label7A = new Label("\nDie 1: " + aDice2[0]);
		       	if (RollA < 1) {
		       		   label7A.setStyle("-fx-border-color: red");
		       	   }
		       	   final Label label8A = new Label("\nDie 2: " + aDice2[1]);
		       	   if (RollA < 2) {
		       		   label8A.setStyle("-fx-border-color: red");
		       	   }
		       	   
		       	   final Label label9A = new Label("\nDie 3: " + aDice2[2]);   
		       	if (RollA < 3) {
		       		   label9A.setStyle("-fx-border-color: red");
		       	   }
		       	   final Label label10A = new Label("\nDie 4: " + aDice2[3]);
		       	if (RollA < 4) {
		       		   label10A.setStyle("-fx-border-color: red");
		       	   }
		       	   final Label label11A = new Label("\nDie 5: " + aDice2[4]);
		       	if (RollA < 5) {
		       		   label11A.setStyle("-fx-border-color: red");
		       	   }
		       	      
		              
		            //place label 0
		       	   root2.add(label6A,0,9);
		       	   //place label2 
		       	   root2.add(label7A,0,10);
		       	 //place label2  
		       	   root2.add(label8A,0,11);
		       	 //place label2  
		       	   root2.add(label9A,0,12);
		       	 //place label2  
		       	   root2.add(label10A,0,13);
		       	 //place label2  
		       	   root2.add(label11A,0,14);
		       	   
		        
		          }
		        
		        }
		    });
		  
		  
		  TextField LastinputA;
		  root2.add(new Label ("How many dice to hold: "), 0, 19);
		  LastinputA = new TextField();
		  
		  root2.add(LastinputA, 0, 20);
		  
		  Button Enter2A = new Button ("Press for second dice roll!");
		  root2.add(Enter2A, 0, 21);
		  
		  
		  Enter2A.setOnAction(new EventHandler<ActionEvent>() {
		        @Override public void handle(ActionEvent e) {
		          int  RollB = Integer.parseInt(LastinputA.getText());
		          
		        //input validation
		          if(RollB < 1 || RollB > 6) {
		        	final  Label InvalidData2 = new Label("Error! Input must be an integer and 1-6");
		        	root2.add(InvalidData2, 1, 20);
		        	  
		          }
		          
		          
		        
		          if (RollB > 0) {
		          
		              Random rand2 = new Random();
		              for (int B = 0; B < RollB; B++) {
		              int	RoleB = 1 + rand2.nextInt(6); // generates more numbers between 1-6 to simulate dice roll
		              	aDice2[B] = RoleB;
		              	
		              //print out dice rolls for texting
		    	        System.out.print("\n\nDice Roll: " + aDice2[B]);
		              }
		              
		           // adds second set of dice roles
		       	   final Label label12A = new Label("\n\nResult of Third set of Dice Rolls(Red Border Indicates dice held):");
		       	   final Label label13A = new Label("\nDie 1: " + aDice2[0]);
		       	if (RollB < 1) {
		       		   label13A.setStyle("-fx-border-color: red");
		       	   }
		       	   final Label label14A = new Label("\nDie 2: " + aDice2[1]);
		       	if (RollB < 2) {
		       		   label14A.setStyle("-fx-border-color: red");
		       	   }
		       	   final Label label15A = new Label("\nDie 3: " + aDice2[2]);
		       	if (RollB < 3) {
		       		   label15A.setStyle("-fx-border-color: red");
		       	   }
		       	   final Label label16A = new Label("\nDie 4: " + aDice2[3]);
		       	if (RollB < 4) {
		       		   label16A.setStyle("-fx-border-color: red");
		       	   }
		       	   final Label label17A = new Label("\nDie 5: " + aDice2[4]);
		       	if (RollB < 5) {
		       		   label17A.setStyle("-fx-border-color: red");
		       	   }
		       	      
		              
		            //place label 0
		       	   root2.add(label12A,0,25);
		       	   //place label2 
		       	   root2.add(label13A,0,26);
		       	 //place label2  
		       	   root2.add(label14A,0,27);
		       	 //place label2  
		       	   root2.add(label15A,0,28);
		       	 //place label2  
		       	   root2.add(label16A,0,29);
		       	 //place label2  
		       	   root2.add(label17A,0,30);
		       	   
		       	   
		     
		          }
		        
		        }
		    });
		  
		  Label Label13 = new Label("Choose From Menu options:");
		  root2.add(Label13, 0, 39);
		  
		  TextField PlayersInput2;
		  PlayersInput2 = new TextField();
		  root2.add(PlayersInput2, 0, 40);
	  
		  Button scorebtn2 = new Button ("Score Dice Rolls"); // score button-------------------------------------------->
		  root2.add(scorebtn2, 0, 42);
		  
		  scorebtn2.setOnAction(new EventHandler<ActionEvent>() {
		        @Override public void handle(ActionEvent e) {
		        	
		        	//parses player input
		        	int  Parsedinput = Integer.parseInt(PlayersInput2.getText());
		        	
		        	int score = 0;
		        	
		        	List TopScores = new ArrayList();
		        	
		        
		        	
		        	
		        	int index = 0, i = 0, TotalWon = 0, TotalWon2 = 0;
				      
				      int one = 0, two = 0, three = 0, four = 0, five = 0, six = 0;
				      
				      Arrays.sort(aDice); //sorts array in ascending numerical order
		        	
		        	//Numbers
				      for ( int c = 0; c < 5; c++) {
				        if (aDice[c] == 1) {one++;}
				        if (aDice[c] == 2) {two++; }
				        if (aDice[c] == 3) {three++;}
				        if (aDice[c] == 4) {four++;}
				        if (aDice[c] == 5) {five++;}
				        if (aDice[c] == 6) {six++;}
				      }
				   
				      //calculates straights from the dice rolls
				      if ((aDice[0] == aDice[1] - 1) && (aDice[1] == aDice[2] - 1)
				          && (aDice[2] == aDice[3] - 1) && (aDice[3] == aDice[4] - 1)
				          && (Parsedinput == 3)) 
				      {
				    	  TotalWon2 = 1;
				      } 
				      else if ((one > 0) && (two > 0) && (three > 0) && (four > 0)) 
				      {
				    	  TotalWon2 = 2;
				      } 
				      else if ((three > 0) && (four > 0) && (five > 0) && (six > 0)) 
				      {
				    	  TotalWon2 = 2;
				      } 
				      else if ((two > 0) && (three > 0) && (four > 0) && (five > 0)) 
				      {
				    	  TotalWon2 = 2;
				      }
				   
				      //calculates pairs from rolled dice
				      for (index = 0; index < 5; index++) 
				      {
				        if (index != 0) {
				          if ((aDice[0] == aDice[index])) 
				          {
				        	  TotalWon++;
				          }
				        }
				        if ((index != 0) && (index != 1)) 
				        {
				          if ((aDice[1] == aDice[index])) 
				          {
				        	  TotalWon++;
				          }
				        }
				        if ((index != 0) && (index != 1) && (index != 2)) 
				        {
				          if ((aDice[2] == aDice[index])) 
				          {
				        	  TotalWon++;
				          }
				        }
				        if ((index != 0) && (index != 1) && (index != 2) && (index != 3)) 
				        {
				          if ((aDice[3] == aDice[index])) {
				        	  TotalWon++;
				          }
				        }
				      }
				      
				      
				      
				      
				   String outcome;
				      //Displays outcome of game and What user has scored
				      if ((TotalWon2 == 1) && (Parsedinput == 3)) 
				      {
				    	  final Label scorelabel1 = new Label("Its a straight.");
				    	  root2.add(scorelabel1, 0, 44);
				    	  final Label scoretotal = new Label("Score Total is : " + score);
				    	  root2.add(scoretotal, 1, 44);
				    	  
				        System.out.println("\nIt's a straight.");
				        score = 40;
				        
				        
				      }
				      else if ((TotalWon2 == 2) && (Parsedinput == 4))
				      {
				    	  final Label scorelabel1 = new Label("Its a straight");
				    	  root2.add(scorelabel1, 0, 44);
				    	  final Label scoretotal = new Label("Score Total is : " + score);
				    	  root2.add(scoretotal, 1, 44);
				    	  
				        System.out.println("\nIt's a small straight.");
				        score = 30;
				        
				      }
				      else if ((TotalWon == 10) && (Parsedinput == 1)) 
				      {
				    	  final Label scorelabel1 = new Label("You got Yahtzee Hurray");
				    	  root2.add(scorelabel1, 0, 44);
				    	  final Label scoretotal = new Label("Score Total is : " + score);
				    	  root2.add(scoretotal, 1, 44);
				    	  
				        System.out.println("\nYou got Yatzee Hurray!");
				        score = 50;
				        
				      } 
				      else if ((Parsedinput == 6) && (TotalWon >= 3)) 
				      {
				    	  final Label scorelabel1 = new Label("\nYou rolled three of a kind.");
				    	  root2.add(scorelabel1, 0, 44);
				    	  final Label scoretotal = new Label("Score Total is : " + score);
				    	  root2.add(scoretotal, 1, 44);
				    	  
				        System.out.println("\nThree of a kind.");
				        score = aDice[0] + aDice[1] + aDice[2] + aDice[3] + aDice[4];
				        
				      } 
				      else if ((Parsedinput == 7) && (TotalWon > 0)) 
				      {
				    	  final Label scorelabel1 = new Label("\nYou rolled a pair.");
				    	  root2.add(scorelabel1, 0, 44);
				    	  final Label scoretotal = new Label("Score Total is : " + score);
				    	  root2.add(scoretotal, 1, 44);
				    	  
				    	  
				        System.out.println("\nYou rolled a pair.");
				        score = 5;
				        
				      } 
				      else if ((TotalWon == 2) && (Parsedinput == 8)) 
				      {
				    	  final Label scorelabel1 = new Label("\nYou rolled two pairs.");
				    	  root2.add(scorelabel1, 0, 44);
				    	  final Label scoretotal = new Label("Score Total is : " + score);
				    	  root2.add(scoretotal, 1, 44);
				    	  
				    	  
				        System.out.println("\nYou rolled two pairs.");
				        score = 10;
				        
				      } 
				      else if ((TotalWon == 4) && (Parsedinput == 2)) 
				      {
				    	  final Label scorelabel1 = new Label("You rolled a full house");
				    	  root2.add(scorelabel1, 0, 44);
				    	  final Label scoretotal = new Label("Score Total is : " + score);
				    	  root2.add(scoretotal, 1, 44);
				    	  
				    	  
				    	  
				        System.out.println("\nYou rolled a full house.");
				        score = 25;
				        
				      } 
				      else if ((TotalWon >= 6) && (Parsedinput == 5)) 
				      {
				    	  final Label scorelabel1 = new Label("\nYou rolled four of a kind.");
				    	  root2.add(scorelabel1, 0, 44);
				    	  final Label scoretotal = new Label("Score Total is : " + score);
				    	  root2.add(scoretotal, 1, 44);
				    	  
				        System.out.println("\nYou rolled four of a kind.");
				        score = aDice[0] + aDice[1] + aDice[2] + aDice[3] + aDice[4];
				        
				      } 
				      else if (Parsedinput == 9) 
				      {
				    	  final Label scorelabel1 = new Label("\nYour get " + score + " points..");
				    	  root2.add(scorelabel1, 0, 44);
				    	  final Label scoretotal = new Label("Score Total is : " + score);
				    	  root2.add(scoretotal, 1, 44);
				    	  
				    	  
				        System.out.println("\nYou have " + one + " ones.");
				        score = one;
				        
				      } 
				      else if (Parsedinput == 10) 
				      {
				    	  final Label scorelabel1 = new Label("\nYour get " + two + " points..");
				    	  root2.add(scorelabel1, 0, 44);
				    	  final Label scoretotal = new Label("Score Total is : " + score);
				    	  root2.add(scoretotal, 1, 44);
				    	  
				    	  
				        System.out.println("\nYou have " + two + " twos.");
				        score = two * 2;
				        
				      } 
				      else if (Parsedinput == 11) 
				      {
				    	  final Label scorelabel1 = new Label("\nYou have " + three + " points..");
				    	  root2.add(scorelabel1, 0, 44);
				    	  final Label scoretotal = new Label("Score Total is : " + score);
				    	  root2.add(scoretotal, 1, 44);
				    	  
				    	  
				        System.out.println("\nYou have " + three + " threes.");
				        score = three * 3;
				        
				      } 
				      else if (Parsedinput == 12) 
				      {
				    	  final Label scorelabel1 = new Label("\nYou have " + four + " points..");
				    	  root2.add(scorelabel1, 0, 44);
				    	  final Label scoretotal = new Label("Score Total is : " + score);
				    	  root2.add(scoretotal, 1, 44);
				    	  
				    	  
				        System.out.println("\nYou have " + four + " fours.");
				        score = four * 4;
				      } 
				      else if (Parsedinput == 13) 
				      {
				    	  
				    	  final Label scorelabel1 = new Label("You have" + five + " points..");
				    	  root2.add(scorelabel1, 0, 44);
				    	  final Label scoretotal = new Label("Score Total is : " + score);
				    	  root2.add(scoretotal, 1, 44);
				    	  
				    	  
				    	  
				        System.out.println("\nYou have " + five + " fives.");
				        score = five * 5;
				        
				      } 
				      else if (Parsedinput == 14)
				      {
				    	  final Label scorelabel1 = new Label("Your have " + six + " points..");
				    	  root2.add(scorelabel1, 0, 44);
				    	  final Label scoretotal = new Label("Score Total is : " + score);
				    	  root2.add(scoretotal, 1, 44);
				    	 
				    	  
				        System.out.println("\nYou have " + six + " sixes.");
				        score = six * 6;
				        
				      } 
				      else if (Parsedinput == 15) 
				      {
				    	  
				    	  final Label scorelabel1 = new Label("\nYour get " + score + " points..");
				    	  root2.add(scorelabel1, 0, 44);
				    	  final Label scoretotal = new Label("Score Total is : " + score);
				    	  root2.add(scoretotal, 1, 44);
				    	  
				    	  
				    	  
				        score = aDice[0] + aDice[1] + aDice[2] + aDice[3] + aDice[4];
				        
				        System.out.println("\nYour get " + score + " points.");
				      } 
				      else 
				      {
				    	  final Label scorelabel1 = new Label("\nSorry, nothing.");
				    	  root2.add(scorelabel1, 0, 44);
				    	  
				    	  final Label scoretotal = new Label("Score Total is : " + score);
				    	  root2.add(scoretotal, 1, 44);
				    	  
				    	  
				    	  
				        System.out.println("\nSorry, nothing.");
				        score = 0;
				        outcome = "Sorry, nothing!";
				        
				      }
				      
				     
				      
				      
				      }   	
		       
		        
		        	
		        	
		        	
		        	
		        	
		        	
		        }); //end of score  
	  
		 
	  
	  
	  
	  
	  }); //end of NewGamebtn action script
	  
	  
	   
	   
	   }; //marks end of primary stage

	 
	} //marks end of public class Yahtzee gui
  
	
	               
   //end of Game class         
	        
   
   
	  
	   
   

		        
   
   
   
   
